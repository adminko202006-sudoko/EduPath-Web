<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Staff;
use App\Models\StaffPermission;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class StaffController extends Controller
{
    /**
     * Display a listing of staff.
     */
    public function index()
    {
        $staff = Staff::with([
            'user',
            'academicPrograms',
            'permissions',
        ])
            ->latest()
            ->get();

        return response()->json([
            'success' => true,
            'message' => 'Staff retrieved successfully.',
            'data' => $staff,
        ]);
    }

    /**
     * Store a newly created staff member.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255|unique:users,email',
            'password' => 'required|string|min:8',

            'employee_id' => 'required|string|max:255|unique:staff,employee_id',
            'first_name' => 'required|string|max:255',
            'middle_name' => 'nullable|string|max:255',
            'last_name' => 'required|string|max:255',

            'department' => 'nullable|string|max:255',
            'position' => 'nullable|string|max:255',

            'status' => [
                'nullable',
                Rule::in(['active', 'inactive']),
            ],

            'program_ids' => 'nullable|array',
            'program_ids.*' => 'integer|exists:academic_programs,id',
        ]);

        $result = DB::transaction(function () use ($validated) {

            $user = User::create([
                'name' => $validated['name'],
                'email' => $validated['email'],
                'password' => Hash::make($validated['password']),
                'role' => 'staff',
            ]);

            $staff = Staff::create([
                'user_id' => $user->id,
                'employee_id' => $validated['employee_id'],
                'first_name' => $validated['first_name'],
                'middle_name' => $validated['middle_name'] ?? null,
                'last_name' => $validated['last_name'],
                'department' => $validated['department'] ?? null,
                'position' => $validated['position'] ?? null,
                'status' => $validated['status'] ?? 'active',
            ]);

            if (!empty($validated['program_ids'])) {
                $staff->academicPrograms()->sync($validated['program_ids']);
            }

            StaffPermission::create([
                'staff_id' => $staff->id,
            ]); 

            return $staff;
        });

        $result->load([
            'user',
            'academicPrograms',
            'permissions',
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Staff created successfully.',
            'data' => $result,
        ], 201);
    }

    /**
     * Display the specified staff member.
     */
    public function show(Staff $staff)
    {
        $staff->load([
            'user',
            'academicPrograms',
            'permissions',
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Staff retrieved successfully.',
            'data' => $staff,
        ]);
    }

    /**
     * Update the specified staff member.
     */
    public function update(Request $request, Staff $staff)
    {
        $validated = $request->validate([
            'name' => 'sometimes|required|string|max:255',
            'email' => [
                'sometimes',
                'required',
                'email',
                'max:255',
                Rule::unique('users', 'email')->ignore($staff->user_id),
            ],
            'password' => 'nullable|string|min:8',

            'employee_id' => [
                'sometimes',
                'required',
                'string',
                'max:255',
                Rule::unique('staff', 'employee_id')->ignore($staff->id),
            ],

            'first_name' => 'sometimes|required|string|max:255',
            'middle_name' => 'nullable|string|max:255',
            'last_name' => 'sometimes|required|string|max:255',

            'department' => 'nullable|string|max:255',
            'position' => 'nullable|string|max:255',

            'status' => [
                'sometimes',
                'required',
                Rule::in(['active', 'inactive']),
            ],

            'program_ids' => 'nullable|array',
            'program_ids.*' => 'integer|exists:academic_programs,id',

            'manage_admissions' => 'sometimes|boolean',
            'verify_documents' => 'sometimes|boolean',
            'manage_exams' => 'sometimes|boolean',
            'manage_scholarships' => 'sometimes|boolean',
            'manage_announcements' => 'sometimes|boolean',
            'send_notifications' => 'sometimes|boolean',
            'view_reports' => 'sometimes|boolean',
        ]);

        DB::transaction(function () use ($validated, $staff) {

            $userData = [];

            if (array_key_exists('name', $validated)) {
                $userData['name'] = $validated['name'];
            }

            if (array_key_exists('email', $validated)) {
                $userData['email'] = $validated['email'];
            }

            if (!empty($validated['password'])) {
                $userData['password'] = Hash::make(
                    $validated['password']
                );
            }

            // Staff accounts must remain staff accounts.
            $userData['role'] = 'staff';

            if (!empty($userData)) {
                $staff->user->update($userData);
            }

            $staffData = collect($validated)
                ->only([
                    'employee_id',
                    'first_name',
                    'middle_name',
                    'last_name',
                    'department',
                    'position',
                    'status',
                ])
                ->toArray();

            if (!empty($staffData)) {
                $staff->update($staffData);
            }

            if (array_key_exists('program_ids', $validated)) {
                $staff->academicPrograms()->sync(
                    $validated['program_ids'] ?? []
                );
            }

            $permissionFields = [
                'manage_admissions',
                'verify_documents',
                'manage_exams',
                'manage_scholarships',
                'manage_announcements',
                'send_notifications',
                'view_reports',
            ];

            $permissionData = collect($validated)
                ->only($permissionFields)
                ->toArray();

            if (!empty($permissionData)) {
                $staff->permissions()->updateOrCreate(
                    ['staff_id' => $staff->id],
                    $permissionData
                );
            }
        });

        $staff->load([
            'user',
            'academicPrograms',
            'permissions',
        ]);
        
        return response()->json([
            'success' => true,
            'message' => 'Staff updated successfully.',
            'data' => $staff,
        ]);
    }

    /**
     * Remove the specified staff member.
     */
    public function destroy(Staff $staff)
    {
        DB::transaction(function () use ($staff) {

            $user = $staff->user;

            // Remove the staff profile first.
            $staff->delete();

            // Remove the associated staff user account.
            if ($user) {
                $user->delete();
            }
        });

        return response()->json([
            'success' => true,
            'message' => 'Staff deleted successfully.',
        ]);
    }
}