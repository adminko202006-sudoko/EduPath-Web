<?php

namespace App\Http\Controllers\Api\Admin;


use App\Http\Controllers\Controller;
use App\Models\Applicant;
use App\Models\AdmissionApplication;
use App\Models\ScholarshipApplication;
use App\Models\EntranceExam;
use App\Models\Announcement;

class DashboardController extends Controller
{
    /**
     * Display admin dashboard statistics.
     */
    public function index()
    {
        $totalApplicants = Applicant::count();

        $pendingApplications = AdmissionApplication::where(
            'status',
            'pending'
        )->count();

        $approvedApplications = AdmissionApplication::where(
            'status',
            'approved'
        )->count();

        $rejectedApplications = AdmissionApplication::where(
            'status',
            'rejected'
        )->count();

        $scholarshipApplicants = ScholarshipApplication::count();

        $upcomingExams = EntranceExam::where(
            'exam_date',
            '>=',
            now()->toDateString()
        )
            ->where('is_active', true)
            ->count();

        $announcements = Announcement::where(
            'status',
            'published'
        )->count();

        $recentApplicants = Applicant::with('user')
        ->latest()
        ->take(5)
        ->get();

        return response()->json([
            'success' => true,
            'message' => 'Dashboard data retrieved successfully.',
            'data' => [
                'total_applicants' => $totalApplicants,
                'pending_applications' => $pendingApplications,
                'approved_applications' => $approvedApplications,
                'rejected_applications' => $rejectedApplications,
                'scholarship_applicants' => $scholarshipApplicants,
                'upcoming_exams' => $upcomingExams,
                'published_announcements' => $announcements,
                'recent_applicants' => $recentApplicants,
            ],
        ]);
    }
}