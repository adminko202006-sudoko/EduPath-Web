<?php

namespace App\Http\Controllers\Api\Applicant;

use App\Http\Controllers\Controller;
use App\Models\AdmissionApplication;
use App\Models\EntranceExam;
use App\Models\ExamAssignment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ExamController extends Controller
{
    /**
     * Display the applicant's assigned entrance exams.
     *
     * Eligible applicants:
     * - Have an active applicant profile.
     * - Have a submitted admission application that is pending review.
     *
     * Only active, upcoming exams receive new assignments.
     * Existing assignments are preserved.
     */
    public function index(Request $request)
    {
        $applicant = $request->user()->applicant;

        if (!$applicant || $applicant->is_archived) {
            return response()->json([
                'success' => false,
                'message' => 'An active applicant profile is required.',
                'data' => [],
            ], 403);
        }

        $isEligible = AdmissionApplication::where(
            'applicant_id',
            $applicant->id
        )
            ->whereIn('status', ['pending', 'approved'])
            ->exists();

        if ($isEligible) {
            $upcomingExams = EntranceExam::where('is_active', true)
                ->whereDate('exam_date', '>=', now()->toDateString())
                ->orderBy('exam_date')
                ->orderBy('start_time')
                ->get();

            foreach ($upcomingExams as $exam) {
                DB::transaction(function () use ($exam, $applicant) {
                    // Preserve an existing assignment and its results.
                    $existingAssignment = ExamAssignment::where(
                        'entrance_exam_id',
                        $exam->id
                    )
                        ->where('applicant_id', $applicant->id)
                        ->exists();

                    if ($existingAssignment) {
                        return;
                    }

                    // Lock the exam row while checking available capacity.
                    $lockedExam = EntranceExam::whereKey($exam->id)
                        ->lockForUpdate()
                        ->first();

                    if (
                        !$lockedExam ||
                        !$lockedExam->is_active ||
                        $lockedExam->exam_date < now()->toDateString()
                    ) {
                        return;
                    }

                    // Recheck after locking to avoid duplicate assignments.
                    $alreadyAssigned = ExamAssignment::where(
                        'entrance_exam_id',
                        $lockedExam->id
                    )
                        ->where('applicant_id', $applicant->id)
                        ->exists();

                    if ($alreadyAssigned) {
                        return;
                    }

                    $assignedCount = ExamAssignment::where(
                        'entrance_exam_id',
                        $lockedExam->id
                    )->count();

                    if (
                        $lockedExam->capacity !== null &&
                        $assignedCount >= $lockedExam->capacity
                    ) {
                        return;
                    }

                    ExamAssignment::create([
                        'entrance_exam_id' => $lockedExam->id,
                        'applicant_id' => $applicant->id,
                        'status' => 'scheduled',
                    ]);
                });
            }
        }

        // Return existing assignments so the current frontend can continue
        // displaying exam details, status, scores, and remarks.
        $assignments = ExamAssignment::with('entranceExam')
            ->where('applicant_id', $applicant->id)
            ->whereHas('entranceExam', function ($query) {
                $query->where('is_active', true);
            })
            ->latest()
            ->get();

        return response()->json([
            'success' => true,
            'message' => 'Your entrance exams retrieved successfully.',
            'data' => $assignments,
        ]);
    }

    /**
     * Display a specific exam assignment belonging to the applicant.
     */
    public function show(Request $request, ExamAssignment $assignment)
    {
        $applicant = $request->user()->applicant;

        if (
            !$applicant ||
            $assignment->applicant_id !== $applicant->id
        ) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized access.',
            ], 403);
        }

        $assignment->load('entranceExam');

        return response()->json([
            'success' => true,
            'message' => 'Entrance exam assignment retrieved successfully.',
            'data' => $assignment,
        ]);
    }
}